import React, { useState, useRef, useEffect } from 'react';

interface WhatsAppButtonProps {
  phoneNumber: string;
  message: string;
}

const WhatsAppButton: React.FC<WhatsAppButtonProps> = ({ phoneNumber, message }) => {
  const [position, setPosition] = useState({ x: 24, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const dragStart = useRef({ x: 0, y: 0 });
  const initialPos = useRef({ x: 0, y: 0 });
  const hasMoved = useRef(false);
  const buttonRef = useRef<HTMLDivElement>(null);

  // BUG 2 FIX: Set initial Y après mount (window disponible)
  useEffect(() => {
    setPosition({ x: 24, y: window.innerHeight - 100 });
  }, []);

  const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;

  const onPointerDown = (e: React.PointerEvent) => {
    setIsDragging(true);
    dragStart.current = { x: e.clientX, y: e.clientY };
    initialPos.current = { ...position };
    hasMoved.current = false;
    if (buttonRef.current) buttonRef.current.setPointerCapture(e.pointerId);
  };

  const onPointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    const dx = e.clientX - dragStart.current.x;
    const dy = e.clientY - dragStart.current.y;
    if (Math.abs(dx) > 5 || Math.abs(dy) > 5) hasMoved.current = true;
    setPosition({ x: initialPos.current.x + dx, y: initialPos.current.y + dy });
  };

  const onPointerUp = (e: React.PointerEvent) => {
    if (!isDragging) return;
    setIsDragging(false);
    if (buttonRef.current) buttonRef.current.releasePointerCapture(e.pointerId);

    const screenWidth = window.innerWidth;
    const padding = 24;
    const buttonWidth = 64;

    const targetX = position.x < (screenWidth / 2) - (buttonWidth / 2) ? padding : screenWidth - buttonWidth - padding;
    const targetY = Math.max(padding, Math.min(position.y, window.innerHeight - buttonWidth - padding - 20));

    setPosition({ x: targetX, y: targetY });

    if (!hasMoved.current) {
      window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
    }
  };

  if (position.y === 0) return null; // Pas encore monté

  return (
    <div
      ref={buttonRef}
      id="guide-whatsapp"
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      style={{
        left: `${position.x}px`,
        top: `${position.y}px`,
        transition: isDragging ? 'none' : 'all 0.6s cubic-bezier(0.16, 1, 0.3, 1)',
        touchAction: 'none'
      }}
      className="fixed z-[90] group cursor-pointer"
      aria-label="Contactez-nous sur WhatsApp"
    >
      <div className="absolute bottom-full mb-4 left-1/2 -translate-x-1/2 px-4 py-2 bg-white dark:bg-navy border border-navy/10 dark:border-white/10 rounded-xl whitespace-nowrap shadow-xl opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300 hidden md:block pointer-events-none">
        <span className="text-[10px] font-black uppercase tracking-widest text-brand-blue">Discuter avec un expert</span>
        <div className="absolute top-full left-1/2 -translate-x-1/2 w-2 h-2 bg-white dark:bg-navy border-r border-b border-navy/10 dark:border-white/10 rotate-45 -translate-y-1"></div>
      </div>

      <span className="absolute inset-0 rounded-full bg-[#25D366] animate-ping opacity-20 group-hover:opacity-40"></span>
      <div className="relative flex items-center justify-center w-14 h-14 md:w-16 md:h-16 bg-[#25D366] rounded-full shadow-[0_10px_30px_rgba(37,211,102,0.4)] transition-all duration-300 transform group-hover:scale-110 active:scale-95 group-hover:rotate-6">
        <svg viewBox="0 0 24 24" className="w-8 h-8 md:w-9 md:h-9 fill-white pointer-events-none" xmlns="http://www.w3.org/2000/svg">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.411 0 .01 5.403.007 12.04c0 2.123.554 4.197 1.607 6.034L0 24l6.117-1.605a11.803 11.803 0 005.925 1.586h.005c6.637 0 12.038-5.402 12.041-12.04a11.817 11.817 0 00-3.517-8.482" />
        </svg>
      </div>
    </div>
  );
};

export default WhatsAppButton;
