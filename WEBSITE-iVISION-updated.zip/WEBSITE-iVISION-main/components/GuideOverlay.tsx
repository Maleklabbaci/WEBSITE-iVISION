
import React, { useState, useEffect } from 'react';
import { translations, Language } from '../lib/translations';

interface GuideOverlayProps {
  onClose: () => void;
  language: Language;
}

const GuideOverlay: React.FC<GuideOverlayProps> = ({ onClose, language }) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [targetRect, setTargetRect] = useState<DOMRect | null>(null);
  const isRtl = language === 'ar';
  const stepsCount = 4;
  
  const t = translations[language].guide;
  const stepData = t.steps[currentStep - 1];

  const updateSpotlight = () => {
    const w = window.innerWidth;
    const isMobile = w < 1024;
    
    let targetId = '';
    switch(currentStep) {
      case 1: targetId = 'guide-theme-toggle'; break;
      case 2: targetId = isMobile ? 'guide-mobile-menu' : 'guide-contact-btn'; break;
      case 3: targetId = 'guide-whatsapp'; break;
      case 4: targetId = 'guide-scroll'; break;
    }

    const element = document.getElementById(targetId);
    if (element) {
      setTargetRect(element.getBoundingClientRect());
    } else {
      // If element not found (e.g. mobile transition), don't block, just try to find it again or skip
      setTargetRect(null);
    }
  };

  useEffect(() => {
    updateSpotlight();
    const interval = setInterval(updateSpotlight, 500); // Periodic check to handle layout shifts
    window.addEventListener('resize', updateSpotlight);
    
    return () => {
      clearInterval(interval);
      document.body.style.overflow = 'unset';
      window.removeEventListener('resize', updateSpotlight);
    };
  }, [currentStep, language]);

  useEffect(() => {
    // BUG 7 FIX: Toujours libérer overflow si targetRect est null (évite page bloquée)
    document.body.style.overflow = targetRect ? 'hidden' : 'unset';
    return () => { document.body.style.overflow = 'unset'; };
  }, [targetRect]);

  const nextStep = () => {
    if (currentStep < stepsCount) {
      setCurrentStep(currentStep + 1);
    } else {
      onClose();
    }
  };

  // BUG 7 FIX: Si l'élément cible est introuvable, passer au step suivant après 800ms
  React.useEffect(() => {
    if (!targetRect) {
      const timer = setTimeout(() => {
        if (currentStep < stepsCount) setCurrentStep(prev => prev + 1);
        else onClose();
      }, 800);
      return () => clearTimeout(timer);
    }
  }, [targetRect]);

  if (!targetRect) return null;

  const cx = targetRect.left + targetRect.width / 2;
  const cy = targetRect.top + targetRect.height / 2;
  const r = Math.max(targetRect.width, targetRect.height) / 2 + 15;

  const cardWidth = Math.min(320, window.innerWidth - 40);
  let cardX = cx - cardWidth / 2;
  let cardY = cy + r + 24;

  if (cardX < 20) cardX = 20;
  if (cardX + cardWidth > window.innerWidth - 20) cardX = window.innerWidth - cardWidth - 20;

  // On very small screens or bottom elements, place card above
  if (cardY + 180 > window.innerHeight) {
    cardY = cy - r - 180;
    if (cardY < 20) cardY = 20; // Last resort fallback
  }

  return (
    <div className="fixed inset-0 z-[300] pointer-events-none overflow-hidden">
      <svg className="absolute inset-0 w-full h-full pointer-events-auto">
        <defs>
          <mask id="guide-mask">
            <rect width="100%" height="100%" fill="white" />
            <circle 
              cx={cx} 
              cy={cy} 
              r={r} 
              fill="black" 
              className="transition-all duration-500 ease-[cubic-bezier(0.16,1,0.3,1)]"
            />
          </mask>
        </defs>
        <rect 
          width="100%" 
          height="100%" 
          fill="rgba(5, 10, 31, 0.9)" 
          mask="url(#guide-mask)" 
          className="transition-all duration-500" 
          onClick={nextStep}
        />
      </svg>

      <div 
        className="absolute border-2 border-brand-blue rounded-full transition-all duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] shadow-[0_0_40px_rgba(0,51,255,0.6)] animate-pulse"
        style={{
          left: cx - r,
          top: cy - r,
          width: r * 2,
          height: r * 2,
        }}
      />

      <div 
        className="absolute pointer-events-auto transition-all duration-500"
        style={{ 
          top: cardY, 
          left: cardX,
          width: cardWidth
        }}
      >
        <div className="bg-white dark:bg-navy p-6 rounded-[2rem] shadow-[0_20px_50px_rgba(0,0,0,0.5)] border border-navy/10 dark:border-white/10 border-b-4 border-b-brand-blue animate-fade-in-up">
          <div className="flex items-center gap-3 mb-3">
             <div className="w-8 h-8 bg-brand-blue/10 rounded-full flex items-center justify-center text-brand-blue">
                <span className="text-xs font-black">{currentStep}</span>
             </div>
             <h4 className="text-brand-blue text-[10px] font-black uppercase tracking-widest">
               {stepData.title}
             </h4>
          </div>
          <p className="text-navy dark:text-white text-sm font-bold leading-relaxed mb-6">
            {stepData.desc}
          </p>
          <div className={`flex items-center justify-between ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
             <button 
               onClick={onClose}
               className="text-[10px] font-black text-navy/40 dark:text-white/40 hover:text-brand-blue uppercase tracking-widest transition-colors px-2 py-1"
             >
               {t.skip}
             </button>
             <button 
               onClick={nextStep}
               className="text-[10px] font-black text-brand-blue uppercase tracking-widest hover:translate-x-1 transition-transform flex items-center gap-2"
             >
               {currentStep < stepsCount ? t.next : t.finish}
               <svg className={`w-3 h-3 ${isRtl ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M17 8l4 4m0 0l-4 4m4-4H3" />
               </svg>
             </button>
          </div>
        </div>
      </div>

      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex gap-3 pointer-events-auto">
        {[...Array(stepsCount)].map((_, i) => (
          <div 
            key={i} 
            className={`h-1.5 rounded-full transition-all duration-500 ${currentStep === (i+1) ? 'w-10 bg-brand-blue' : 'w-2 bg-white/20'}`}
          />
        ))}
      </div>
    </div>
  );
};

export default GuideOverlay;
